
import React, { useState } from 'react';
import { Phone, Mail, MapPin, Clock, MessageSquare, Send } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

const Contact = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    // Here you would typically send the form data to your backend
    console.log('Form submitted:', formData);
    
    toast({
      title: "Quote request sent!",
      description: "We'll get back to you within 24 hours."
    });

    // Reset form
    setFormData({
      name: '',
      email: '',
      phone: '',
      service: '',
      message: ''
    });
  };

  const contactInfo = [
    {
      icon: Phone,
      title: "Phone",
      details: ["+27 608 423 588", "+27 649 997 982"],
      action: "tel:+27608423588"
    },
    {
      icon: Mail,
      title: "Email",
      details: ["info@ditau.co.za", "quotes@ditau.co.za"],
      action: "mailto:info@ditau.co.za"
    },
    {
      icon: MapPin,
      title: "Location",
      details: ["59th Avenue 1108 Seshego, Zone C", "No18 Mentz Mshongoville, next to Megoreng Primary"],
      action: "#"
    },
    {
      icon: Clock,
      title: "Business Hours",
      details: ["Mon - Fri: 7:00 AM - 5:00 PM", "Sat: 8:00 AM - 1:00 PM"],
      action: "#"
    }
  ];

  return (
    <section id="contact" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-heading font-bold text-steel-dark mb-6">
              Get In Touch
            </h2>
            <div className="w-24 h-1 bg-industrial-blue mx-auto mb-6"></div>
            <p className="text-xl text-steel-gray max-w-3xl mx-auto leading-relaxed">
              Ready to start your next steel fabrication project? Contact us for a free consultation and quote.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div>
              <h3 className="text-2xl font-heading font-bold text-steel-dark mb-8">
                Contact Information
              </h3>
              
              <div className="grid sm:grid-cols-2 gap-6 mb-8">
                {contactInfo.map((info, index) => (
                  <Card key={index} className="border-steel-gray/20 hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-industrial-blue/10 rounded-lg flex items-center justify-center flex-shrink-0">
                          <info.icon className="text-industrial-blue" size={24} />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-steel-dark mb-2">{info.title}</h4>
                          {info.details.map((detail, detailIndex) => (
                            <p key={detailIndex} className="text-steel-gray text-sm mb-1">
                              {detail}
                            </p>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* WhatsApp Button */}
              <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center">
                    <MessageSquare className="text-white" size={24} />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-steel-dark mb-1">WhatsApp</h4>
                    <p className="text-steel-gray text-sm mb-3">
                      Get instant quotes and quick responses
                    </p>
                    <Button 
                      onClick={() => window.open('https://wa.me/27608423588', '_blank')}
                      className="bg-green-500 hover:bg-green-600 text-white"
                    >
                      Chat on WhatsApp
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div>
              <Card className="border-steel-gray/20">
                <CardHeader>
                  <h3 className="text-2xl font-heading font-bold text-steel-dark">
                    Request a Quote
                  </h3>
                  <p className="text-steel-gray">
                    Fill out the form below and we'll get back to you with a detailed quote.
                  </p>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium text-steel-dark mb-2">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 border border-steel-gray/30 rounded-lg focus:ring-2 focus:ring-industrial-blue focus:border-transparent"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-steel-dark mb-2">
                          Phone Number
                        </label>
                        <input
                          type="tel"
                          id="phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 border border-steel-gray/30 rounded-lg focus:ring-2 focus:ring-industrial-blue focus:border-transparent"
                        />
                      </div>
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-steel-dark mb-2">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-steel-gray/30 rounded-lg focus:ring-2 focus:ring-industrial-blue focus:border-transparent"
                        required
                      />
                    </div>

                    <div>
                      <label htmlFor="service" className="block text-sm font-medium text-steel-dark mb-2">
                        Service Required
                      </label>
                      <select
                        id="service"
                        name="service"
                        value={formData.service}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-steel-gray/30 rounded-lg focus:ring-2 focus:ring-industrial-blue focus:border-transparent"
                      >
                        <option value="">Select a service</option>
                        <option value="gate-automation">Gate Automation</option>
                        <option value="welding">Professional Welding</option>
                        <option value="steel-fencing">Steel Fencing</option>
                        <option value="custom-fabrication">Custom Fabrication</option>
                        <option value="installation">Installation Services</option>
                        <option value="maintenance">Maintenance & Repair</option>
                      </select>
                    </div>

                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-steel-dark mb-2">
                        Project Details *
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        rows={5}
                        className="w-full px-4 py-3 border border-steel-gray/30 rounded-lg focus:ring-2 focus:ring-industrial-blue focus:border-transparent resize-none"
                        placeholder="Please describe your project requirements, dimensions, timeline, and any other relevant details..."
                        required
                      ></textarea>
                    </div>

                    <Button 
                      type="submit"
                      className="w-full bg-industrial-blue hover:bg-industrial-blue/90 text-white py-3 text-lg font-semibold group"
                    >
                      Send Quote Request
                      <Send className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
