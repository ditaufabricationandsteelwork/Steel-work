
import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <header className={`fixed top-0 w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-steel-dark/95 backdrop-blur-sm shadow-lg' : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <img 
              src="/lovable-uploads/b906dc53-f70a-4858-8c51-c8dd72863c3c.png" 
              alt="Ditau Fabrication Logo" 
              className="h-12 w-auto"
            />
            <div>
              <h1 className="text-white font-heading font-bold text-lg leading-tight">
                Ditau Fabrication
              </h1>
              <p className="text-steel-silver text-xs">& Steel Work</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button onClick={() => scrollToSection('home')} 
                    className="text-white hover:text-industrial-gold transition-colors">
              Home
            </button>
            <button onClick={() => scrollToSection('about')} 
                    className="text-white hover:text-industrial-gold transition-colors">
              About
            </button>
            <button onClick={() => scrollToSection('services')} 
                    className="text-white hover:text-industrial-gold transition-colors">
              Services
            </button>
            <button onClick={() => scrollToSection('gallery')} 
                    className="text-white hover:text-industrial-gold transition-colors">
              Gallery
            </button>
            <button onClick={() => scrollToSection('contact')} 
                    className="text-white hover:text-industrial-gold transition-colors">
              Contact
            </button>
          </nav>

          {/* Contact Info & CTA */}
          <div className="hidden lg:flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-steel-silver">
              <Phone size={16} />
              <span className="text-sm">+27 608 423 588</span>
            </div>
            <Button onClick={() => scrollToSection('contact')} 
                    className="bg-industrial-blue hover:bg-industrial-blue/90 text-white">
              Get Quote
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-white p-2"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-steel-dark/95 backdrop-blur-sm border-t border-steel-gray/20">
            <nav className="flex flex-col space-y-4 p-4">
              <button onClick={() => scrollToSection('home')} 
                      className="text-white hover:text-industrial-gold transition-colors text-left">
                Home
              </button>
              <button onClick={() => scrollToSection('about')} 
                      className="text-white hover:text-industrial-gold transition-colors text-left">
                About
              </button>
              <button onClick={() => scrollToSection('services')} 
                      className="text-white hover:text-industrial-gold transition-colors text-left">
                Services
              </button>
              <button onClick={() => scrollToSection('gallery')} 
                      className="text-white hover:text-industrial-gold transition-colors text-left">
                Gallery
              </button>
              <button onClick={() => scrollToSection('contact')} 
                      className="text-white hover:text-industrial-gold transition-colors text-left">
                Contact
              </button>
              <div className="pt-4 border-t border-steel-gray/20">
                <Button onClick={() => scrollToSection('contact')} 
                        className="w-full bg-industrial-blue hover:bg-industrial-blue/90 text-white">
                  Get Quote
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
