
import React from 'react';
import { Phone, Mail, MapPin, Facebook, Instagram, Linkedin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-steel-dark text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <img 
                src="/lovable-uploads/b906dc53-f70a-4858-8c51-c8dd72863c3c.png" 
                alt="Ditau Fabrication Logo" 
                className="h-12 w-auto"
              />
              <div>
                <h3 className="font-heading font-bold text-lg leading-tight">
                  Ditau Fabrication
                </h3>
                <p className="text-steel-silver text-sm">& Steel Work (PTY) Ltd</p>
              </div>
            </div>
            
            <p className="text-steel-silver mb-6 leading-relaxed max-w-md">
              Professional steel fabrication and welding services. Built on strength, driven by precision. 
              Serving South Africa with quality metalwork solutions since 2008.
            </p>

            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="text-industrial-blue" size={18} />
                <span className="text-steel-silver">+27 608 423 588</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="text-industrial-blue" size={18} />
                <span className="text-steel-silver">+27 649 997 982</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="text-industrial-blue" size={18} />
                <span className="text-steel-silver">info@ditau.co.za</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="text-industrial-blue mt-1" size={18} />
                <div className="text-steel-silver">
                  <p>59th Avenue 1108 Seshego, Zone C</p>
                  <p>No18 Mentz Mshongoville, next to Megoreng Primary</p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading font-bold text-lg mb-6">Quick Links</h4>
            <nav className="space-y-3">
              <button 
                onClick={() => scrollToSection('home')}
                className="block text-steel-silver hover:text-industrial-gold transition-colors"
              >
                Home
              </button>
              <button 
                onClick={() => scrollToSection('about')}
                className="block text-steel-silver hover:text-industrial-gold transition-colors"
              >
                About Us
              </button>
              <button 
                onClick={() => scrollToSection('services')}
                className="block text-steel-silver hover:text-industrial-gold transition-colors"
              >
                Services
              </button>
              <button 
                onClick={() => scrollToSection('gallery')}
                className="block text-steel-silver hover:text-industrial-gold transition-colors"
              >
                Gallery
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="block text-steel-silver hover:text-industrial-gold transition-colors"
              >
                Contact
              </button>
            </nav>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-heading font-bold text-lg mb-6">Our Services</h4>
            <ul className="space-y-3 text-steel-silver">
              <li className="hover:text-industrial-gold transition-colors cursor-pointer">
                Gate Automation
              </li>
              <li className="hover:text-industrial-gold transition-colors cursor-pointer">
                Professional Welding
              </li>
              <li className="hover:text-industrial-gold transition-colors cursor-pointer">
                Steel Fencing
              </li>
              <li className="hover:text-industrial-gold transition-colors cursor-pointer">
                Custom Fabrication
              </li>
              <li className="hover:text-industrial-gold transition-colors cursor-pointer">
                Installation Services
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-steel-gray/30 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            {/* Copyright */}
            <div className="text-center md:text-left">
              <p className="text-steel-silver text-sm">
                © {currentYear} Ditau Fabrication and Steel Work (PTY) Ltd. All rights reserved.
              </p>
              <p className="text-steel-silver text-xs mt-1">
                Company Registration: 2023/516240/07
              </p>
            </div>

            {/* Social Media */}
            <div className="flex items-center space-x-4">
              <span className="text-steel-silver text-sm mr-2">Follow us:</span>
              <a 
                href="https://facebook.com/ditaufabrication" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 bg-steel-gray/20 rounded-lg flex items-center justify-center hover:bg-industrial-blue transition-colors"
              >
                <Facebook size={18} />
              </a>
              <a 
                href="https://instagram.com/ditaufabrication" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 bg-steel-gray/20 rounded-lg flex items-center justify-center hover:bg-industrial-blue transition-colors"
              >
                <Instagram size={18} />
              </a>
              <a 
                href="https://linkedin.com/company/ditaufabrication" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 bg-steel-gray/20 rounded-lg flex items-center justify-center hover:bg-industrial-blue transition-colors"
              >
                <Linkedin size={18} />
              </a>
            </div>
          </div>

          {/* Certifications */}
          <div className="mt-8 text-center">
            <p className="text-steel-silver text-sm mb-2">
              Certified & Compliant
            </p>
            <div className="flex flex-wrap justify-center gap-4 text-xs text-steel-silver">
              <span className="bg-steel-gray/20 px-3 py-1 rounded">ISO 9001 Certified</span>
              <span className="bg-steel-gray/20 px-3 py-1 rounded">SAIW Qualified Welders</span>
              <span className="bg-steel-gray/20 px-3 py-1 rounded">OHSAS 18001 Compliant</span>
              <span className="bg-steel-gray/20 px-3 py-1 rounded">BEE Level 4</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
