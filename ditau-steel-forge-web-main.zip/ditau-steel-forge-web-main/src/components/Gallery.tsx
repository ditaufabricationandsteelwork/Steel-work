
import React, { useState } from 'react';
import { ExternalLink, ChevronLeft, ChevronRight } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const Gallery = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', name: 'All Projects' },
    { id: 'automation', name: 'Gate Automation' },
    { id: 'gates', name: 'Gates & Fencing' },
    { id: 'welding', name: 'Welding Services' },
    { id: 'installation', name: 'Installation' }
  ];

  const projects = [
    {
      id: 1,
      title: "Gate Automation System",
      category: 'automation',
      description: "Professional gate automation control system installation with advanced circuitry and safety features",
      image: "/lovable-uploads/a1f68c78-d4a7-4a5f-95c0-82b0b6620f3c.png"
    },
    {
      id: 2,
      title: "Automated Gate Controller",
      category: 'automation',
      description: "High-tech gate automation system with comprehensive wiring and control panel setup",
      image: "/lovable-uploads/f14b63be-8dac-4f25-a335-69f5321c65a0.png"
    },
    {
      id: 3,
      title: "Professional Welding Work",
      category: 'welding',
      description: "Skilled welding services for structural steel components and gate mechanisms",
      image: "/lovable-uploads/fef1a368-57e5-4adf-bb67-67c9e80f7242.png"
    },
    {
      id: 4,
      title: "On-Site Welding Services",
      category: 'welding',
      description: "Mobile welding services for gate repairs and structural modifications",
      image: "/lovable-uploads/ced026a5-d075-461c-8d55-f18d5d825f86.png"
    },
    {
      id: 5,
      title: "Custom Steel Fencing",
      category: 'gates',
      description: "High-quality steel palisade fencing with professional finish and installation",
      image: "/lovable-uploads/e0f0a3bd-744e-486c-9286-2f568e256f4f.png"
    },
    {
      id: 6,
      title: "Automated Gate Installation",
      category: 'installation',
      description: "Complete automated gate system with track installation and safety features",
      image: "/lovable-uploads/a55eeaae-72d7-4843-8a9b-1242f9b9c45e.png"
    }
  ];

  const filteredProjects = selectedCategory === 'all' 
    ? projects 
    : projects.filter(project => project.category === selectedCategory);

  return (
    <section id="gallery" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-heading font-bold text-steel-dark mb-6">
              Our Work
            </h2>
            <div className="w-24 h-1 bg-industrial-blue mx-auto mb-6"></div>
            <p className="text-xl text-steel-gray max-w-3xl mx-auto leading-relaxed">
              Explore our portfolio of completed projects showcasing our expertise in steel fabrication, gate automation, and welding services
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                  selectedCategory === category.id
                    ? 'bg-industrial-blue text-white shadow-lg'
                    : 'bg-muted text-steel-gray hover:bg-steel-gray/20'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>

          {/* Projects Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project) => (
              <Card key={project.id} className="border-steel-gray/20 overflow-hidden hover:shadow-xl transition-all duration-300 group">
                <div className="relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-steel-dark/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                    <div className="p-4 text-white">
                      <ExternalLink size={24} className="mb-2" />
                      <p className="text-sm">View Details</p>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-heading font-bold text-steel-dark mb-3 group-hover:text-industrial-blue transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-steel-gray leading-relaxed">
                    {project.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Workshop Section */}
          <div className="mt-20">
            <div className="bg-gradient-to-r from-muted/50 to-muted/80 rounded-lg p-8">
              <div className="grid lg:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-3xl font-heading font-bold text-steel-dark mb-6">
                    Professional Services
                  </h3>
                  <p className="text-steel-gray mb-6 leading-relaxed">
                    Our skilled team delivers comprehensive steel fabrication and automation solutions. From custom gate 
                    systems to complex welding projects, we ensure every installation meets the highest standards of 
                    quality and safety.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-center text-steel-gray">
                      <div className="w-2 h-2 bg-industrial-blue rounded-full mr-3"></div>
                      Gate automation systems
                    </li>
                    <li className="flex items-center text-steel-gray">
                      <div className="w-2 h-2 bg-industrial-blue rounded-full mr-3"></div>
                      Professional welding services
                    </li>
                    <li className="flex items-center text-steel-gray">
                      <div className="w-2 h-2 bg-industrial-blue rounded-full mr-3"></div>
                      Steel fencing and palisades
                    </li>
                    <li className="flex items-center text-steel-gray">
                      <div className="w-2 h-2 bg-industrial-blue rounded-full mr-3"></div>
                      On-site installation and repair
                    </li>
                  </ul>
                </div>
                <div className="relative">
                  <div className="w-full h-80 bg-gradient-to-br from-steel-gray/20 to-industrial-blue/20 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-industrial-blue/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                        <ExternalLink className="text-industrial-blue" size={32} />
                      </div>
                      <p className="text-steel-gray">Quality Workmanship</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Gallery;
