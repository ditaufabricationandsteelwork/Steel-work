
import React from 'react';
import { ArrowRight, Shield, Award, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Hero = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background with gradient overlay */}
      <div className="absolute inset-0 steel-gradient">
        <div className="absolute inset-0 bg-gradient-to-r from-steel-dark/80 via-steel-dark/60 to-transparent"></div>
      </div>

      {/* Floating industrial elements */}
      <div className="absolute top-20 right-20 w-32 h-32 border-2 border-steel-silver/20 rounded-lg rotate-45 animate-float hidden lg:block"></div>
      <div className="absolute bottom-40 left-20 w-20 h-20 border border-industrial-blue/30 rounded-full animate-float delay-1000 hidden lg:block"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main Heading */}
          <div className="animate-slide-up">
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-heading font-black text-white mb-6 leading-tight">
              DITAU
              <span className="block text-industrial-blue">FABRICATION</span>
            </h1>
            <div className="w-24 h-1 bg-industrial-gold mx-auto mb-8"></div>
          </div>

          {/* Tagline */}
          <div className="animate-slide-up delay-200">
            <p className="text-xl md:text-2xl lg:text-3xl text-steel-silver mb-4 font-light">
              Built on Strength.
            </p>
            <p className="text-xl md:text-2xl lg:text-3xl text-white mb-12 font-medium">
              Driven by Precision.
            </p>
          </div>

          {/* Features */}
          <div className="animate-slide-up delay-400">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              <div className="flex flex-col items-center space-y-3">
                <div className="w-16 h-16 bg-industrial-blue/20 rounded-lg flex items-center justify-center industrial-glow">
                  <Shield className="text-industrial-blue" size={32} />
                </div>
                <h3 className="text-white font-semibold">Certified Quality</h3>
                <p className="text-steel-silver text-sm text-center">Professional grade materials and workmanship</p>
              </div>
              
              <div className="flex flex-col items-center space-y-3">
                <div className="w-16 h-16 bg-industrial-gold/20 rounded-lg flex items-center justify-center">
                  <Award className="text-industrial-gold" size={32} />
                </div>
                <h3 className="text-white font-semibold">Expert Craftsmanship</h3>
                <p className="text-steel-silver text-sm text-center">Years of experience in steel fabrication</p>
              </div>
              
              <div className="flex flex-col items-center space-y-3">
                <div className="w-16 h-16 bg-steel-silver/20 rounded-lg flex items-center justify-center">
                  <Zap className="text-steel-silver" size={32} />
                </div>
                <h3 className="text-white font-semibold">Fast Delivery</h3>
                <p className="text-steel-silver text-sm text-center">Efficient project completion times</p>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="animate-slide-up delay-600">
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                onClick={() => scrollToSection('contact')}
                size="lg"
                className="bg-industrial-blue hover:bg-industrial-blue/90 text-white px-8 py-4 text-lg font-semibold group"
              >
                Request a Quote
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
              </Button>
              
              <Button 
                onClick={() => scrollToSection('services')}
                variant="outline"
                size="lg"
                className="border-steel-silver text-steel-silver hover:bg-steel-silver hover:text-steel-dark px-8 py-4 text-lg font-semibold"
              >
                View Services
              </Button>
            </div>
          </div>

          {/* Scroll indicator */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
            <div className="w-6 h-10 border-2 border-steel-silver rounded-full flex justify-center">
              <div className="w-1 h-3 bg-steel-silver rounded-full mt-2 animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
