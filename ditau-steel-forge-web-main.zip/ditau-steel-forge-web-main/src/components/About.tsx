
import React from 'react';
import { Users, Target, Eye, Heart } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const About = () => {
  return (
    <section id="about" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-heading font-bold text-steel-dark mb-6">
              About Ditau Fabrication
            </h2>
            <div className="w-24 h-1 bg-industrial-blue mx-auto mb-6"></div>
            <p className="text-xl text-steel-gray max-w-3xl mx-auto leading-relaxed">
              Established as a leader in steel fabrication and welding services, Ditau Fabrication and Steel Work (PTY) Ltd 
              has been delivering exceptional metalwork solutions across South Africa.
            </p>
          </div>

          {/* Company Story */}
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h3 className="text-2xl font-heading font-bold text-steel-dark mb-6">Our Story</h3>
              <p className="text-steel-gray mb-6 leading-relaxed">
                Founded with a passion for precision and quality, Ditau Fabrication has grown from a small workshop 
                to a comprehensive steel fabrication company. We specialize in custom metalwork, structural steel, 
                and innovative welding solutions for both commercial and residential projects.
              </p>
              <p className="text-steel-gray mb-6 leading-relaxed">
                Our team of certified professionals brings decades of combined experience, ensuring every project 
                meets the highest standards of quality and safety. From intricate decorative pieces to large-scale 
                structural work, we deliver excellence in every weld.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-industrial-blue mb-2">500+</div>
                  <div className="text-steel-gray">Projects Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-industrial-blue mb-2">15+</div>
                  <div className="text-steel-gray">Years Experience</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="w-full h-96 bg-gradient-to-br from-steel-gray/20 to-industrial-blue/20 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <Users className="text-industrial-blue mx-auto mb-4" size={64} />
                  <p className="text-steel-gray">Professional Team at Work</p>
                </div>
              </div>
            </div>
          </div>

          {/* Mission, Vision, Values */}
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-steel-gray/20 hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-industrial-blue/10 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <Target className="text-industrial-blue" size={32} />
                </div>
                <h3 className="text-xl font-heading font-bold text-steel-dark mb-4">Our Mission</h3>
                <p className="text-steel-gray leading-relaxed">
                  To deliver superior steel fabrication and welding services that exceed client expectations 
                  through innovation, quality craftsmanship, and unwavering commitment to safety.
                </p>
              </CardContent>
            </Card>

            <Card className="border-steel-gray/20 hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-industrial-gold/10 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <Eye className="text-industrial-gold" size={32} />
                </div>
                <h3 className="text-xl font-heading font-bold text-steel-dark mb-4">Our Vision</h3>
                <p className="text-steel-gray leading-relaxed">
                  To be South Africa's most trusted steel fabrication company, recognized for excellence, 
                  innovation, and our contribution to building stronger communities.
                </p>
              </CardContent>
            </Card>

            <Card className="border-steel-gray/20 hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-steel-silver/20 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <Heart className="text-steel-gray" size={32} />
                </div>
                <h3 className="text-xl font-heading font-bold text-steel-dark mb-4">Our Values</h3>
                <p className="text-steel-gray leading-relaxed">
                  Quality, integrity, safety, and customer satisfaction drive everything we do. 
                  We believe in building lasting relationships through honest work and exceptional results.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
