
import React from 'react';
import { Wrench, Hammer, Shield, Home, Building, Cog } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

const Services = () => {
  const services = [
    {
      icon: Wrench,
      title: "Custom Steel Fabrication",
      description: "Bespoke metalwork solutions tailored to your specific requirements, from design to completion.",
      features: ["Custom Design", "Precision Cutting", "Professional Finishing"]
    },
    {
      icon: Hammer,
      title: "Professional Welding",
      description: "Expert welding services using state-of-the-art equipment and certified welding techniques.",
      features: ["MIG/TIG Welding", "Arc Welding", "Certified Welders"]
    },
    {
      icon: Building,
      title: "Structural Steel",
      description: "Comprehensive structural steelwork for commercial and industrial construction projects.",
      features: ["Steel Frameworks", "Load-bearing Structures", "Industrial Buildings"]
    },
    {
      icon: Home,
      title: "Gates & Balustrades",
      description: "Security gates, decorative railings, and safety balustrades for residential and commercial use.",
      features: ["Security Gates", "Decorative Railings", "Safety Barriers"]
    },
    {
      icon: Shield,
      title: "Security Solutions",
      description: "Robust security installations including burglar bars, security doors, and protective barriers.",
      features: ["Burglar Bars", "Security Doors", "Protective Barriers"]
    },
    {
      icon: Cog,
      title: "Maintenance & Repair",
      description: "Comprehensive maintenance and repair services to keep your steel structures in optimal condition.",
      features: ["Preventive Maintenance", "Emergency Repairs", "Restoration Services"]
    }
  ];

  return (
    <section id="services" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-heading font-bold text-steel-dark mb-6">
              Our Services
            </h2>
            <div className="w-24 h-1 bg-industrial-blue mx-auto mb-6"></div>
            <p className="text-xl text-steel-gray max-w-3xl mx-auto leading-relaxed">
              Comprehensive steel fabrication and welding services for all your metalwork needs
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="border-steel-gray/20 hover:shadow-xl transition-all duration-300 hover:-translate-y-2 group">
                <CardHeader className="pb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-industrial-blue/10 to-industrial-blue/20 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <service.icon className="text-industrial-blue" size={32} />
                  </div>
                  <h3 className="text-xl font-heading font-bold text-steel-dark group-hover:text-industrial-blue transition-colors">
                    {service.title}
                  </h3>
                </CardHeader>
                <CardContent>
                  <p className="text-steel-gray mb-6 leading-relaxed">
                    {service.description}
                  </p>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-sm text-steel-gray">
                        <div className="w-2 h-2 bg-industrial-blue rounded-full mr-3"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Call to Action */}
          <div className="text-center mt-16">
            <div className="bg-gradient-to-r from-industrial-blue to-steel-gray rounded-lg p-8 text-white">
              <h3 className="text-2xl font-heading font-bold mb-4">
                Need a Custom Solution?
              </h3>
              <p className="text-lg mb-6 opacity-90">
                We specialize in creating unique steel fabrication solutions tailored to your specific requirements.
              </p>
              <button 
                onClick={() => {
                  const element = document.getElementById('contact');
                  if (element) element.scrollIntoView({ behavior: 'smooth' });
                }}
                className="bg-white text-industrial-blue px-8 py-3 rounded-lg font-semibold hover:bg-steel-silver transition-colors"
              >
                Discuss Your Project
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
